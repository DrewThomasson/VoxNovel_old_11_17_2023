This folder contains ways you can run the tts services in google colab instead of on your local machine if you dont have have a sutable computer
