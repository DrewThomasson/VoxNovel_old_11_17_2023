This folder contains material for training and cloning voices to be used with Bark tts if you prever or want that method, 
